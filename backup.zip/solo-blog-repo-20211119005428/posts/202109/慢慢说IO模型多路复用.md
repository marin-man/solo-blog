title: 慢慢说 IO 模型：多路复用
date: '2021-09-20 20:56:20'
updated: '2021-09-20 21:14:50'
tags: [IO模型]
permalink: /articles/2021/09/20/1632142580621.html
---
![](https://b3logfile.com/bing/20200930.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> 小Q：什么是多路复用呢？

慢慢：理解完 NIO 模型，我们可能会注意到，在 Linux 中，万物皆文件，而文件的话就得要操作到磁盘，而操作磁盘则需要用户态和内核态的切换。在 NIO 模式下，我们不断的去判断连接是否有数据传过来，这里我们就得操作到磁盘。我们在轮询的过程中不断地切换内核态和用户态，这是非常浪费资源的。

于是，我们想，有没有一种方法可以不用到内核态和用户态的切换。

我们可以把轮询的过程交由内核去完成，当内核监听到有连接收到数据时，再告诉我们，从而我们通过线程去处理它。把轮询交由内核，用户态只需收到结果，这个过程就叫多路复用。

![](https://gimg2.baidu.com/image_search/src=http%3A%2F%2Faliyunzixunbucket.oss-cn-beijing.aliyuncs.com%2Fjpg%2F37c09fe7d50d4125203b8636a42cb12c.jpg%3Fx-oss-process%3Dimage%2Fresize%2Cp_100%2Fauto-orient%2C1%2Fquality%2Cq_90%2Fformat%2Cjpg%2Fwatermark%2Cimage_eXVuY2VzaGk%3D%2Ct_100&refer=http%3A%2F%2Faliyunzixunbucket.oss-cn-beijing.aliyuncs.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1634734658&t=7deb56a96119d708aa395d8c1eb01e6e)

<br>

> 小Q：什么是 select，poll，epoll 呢？

慢慢：select 和 poll 跟我们原先的思路一样，只是让内核去执行轮询过程，当内核知道连接有数据时，再通知用户线程。

select 是基于数组的形式，所以它的长度会受到一定的限制。poll 是基于链表的形式，解决了 select 长度不足的问题。它们两个都是将文件描述符放到数组或链表中，然后通过内核不断去轮询，判断其状态是否发生改变，若改变则通过回调的方式通知用户线程。

<br>

> 小Q：那 epoll 又是什么呢？

慢慢：使用 select 和 poll 时，我们发现了以下三个问题：

1. 如何突破文件描述符数量的限制（poll 已经解决）
2. 如何避免用户态和内核态对文件描述符集合的拷贝
3. 如何避免线性遍历文件描述符集合

针对第一点，epoll 采用了红黑树的结构存储文件描述符，这样来在性能上与 poll 的链表相比有了很大的提升。对于第二点，epoll 只开辟了一个空间，即只用内核来存放文件描述符，用户态也是操作这一份空间。

对于第三点，epoll 新增了一个 socket 就绪链表和回调函数。当连接(socket) 有数据时，会自动触发回调函数，将就绪的 socket 放到链表中，同时告诉用户态过来处理。这样的话内核就不用一直去轮询符号表了，实现了 O(1) 的复杂度。

<br>

> 小Q：能不能代码演示呢？

慢慢：这里我们通过代码来演示如何通过 netty 来实现 epoll 模型。

服务端

```java
public class EpollServer {
    public void static main(String[] args) {
        EventLoopGroup bossGroup = new NioEventLoopGroup();   // 监听连接的线程组
        EventLoopGroup workerGroup = new NioEventLoopGroup();  // 处理连接的线程组
  
        try {
            // 1. 启动器，负责组装 netty 组件
            new ServerBootstrap()
                // 2. 添加线程组
                .group(bossGroup, workerGroup)
                // 3. 选择基于 NIO 的服务端 channel 实现
                .channel(NioServerSocketChannel.class)
                // 4. 处理流程
                .childHandler(
                    // 5. channel 代表和客户端进行数据读写的通道 Initializer 初始化，负责添加别的 handler
                    new ChannelInitializer<NioSocketChannel>() {
                        @Override
                        protected void initChannel(NioSocketChannel ch) throws Exception {
                            // 6. 添加具体 handler
                            ch.pipeline().addLast(new StringDecoder());  // 将 bytebuf 转为字符串
                            ch.pipeline().addLast(new ChannelInboundHandlerAdapter() {  // 自定义handler
                                @Override
                                public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
                                // 打印上一步转化好的字符串
                                System.out.println(msg);
                                super.channelRead(ctx, msg);
                            }
                        });
                    }
                })
                .bind(8080)   // 7. 绑定监听端口
                .channel().closeFuture().sync();   // 等待服务端关闭
        } finally {
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();
        }
    }
}
```

客户端

```java
public class EpollClient {

    public static void main(String[] args) throws InterruptedException {
        // 1. 启动类
        new Bootstrap()
                // 2. 添加 eventLoop
                .group(new NioEventLoopGroup())
                // 3. 选择客户端 channel 实现
                .channel(NioSocketChannel.class)
                // 4. 添加处理器
                .handler(new ChannelInitializer<NioSocketChannel>() {
                    @Override  // 在连接建立后被调用
                    protected void initChannel(NioSocketChannel nioSocketChannel) throws Exception {
                        nioSocketChannel.pipeline().addLast(new StringEncoder());
                    }
                })
                // 5. 连接到服务器
                .connect(new InetSocketAddress("localhost", 8080))
                .sync()   // 阻塞方法，直到连接建立
                .channel()   // 代表连接对象
                // 6. 向服务器发送数据
                .writeAndFlush("hello, world");   // 发送数据
    }
}
```
